/**
 * Browser half of dsh-vision-analysis: a `conversation.input.dock`
 * entry that guides the Web UI when the active model cannot take image input.
 *
 * Flow: when the composer holds draft images and the session's current model
 * is NOT confirmed image-capable, the entry renders a hint asking the user to
 * save the image to a local file and send its absolute path, so the host-side
 * `analyze_image` tool parses it directly. Base64 data URLs were tried first
 * (compress → embed in a text prompt → agent calls analyze_image), but the
 * multi-hundred-KB payloads were corrupted in the message→tool→vision-API
 * pipeline, so the banner now only guides toward the reliable local-path
 * route. When the model is image-capable, the entry renders nothing and the
 * native image send path is untouched.
 *
 * Deliberately dependency-light: the entry reads input state through the
 * standard composer provide channel (`useInput`), resolves the current model
 * through the shared API client, and collaborates with the host half only
 * through the `analyze_image` tool itself — no custom client→host RPC is
 * registered.
 * @module dsh-vision-analysis/client
 */
import type { Context } from '@deepseek-ai/cordis';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Composer paste-image interpretation fallback copy. */
        'vision-analysis': (typeof COPY)['zh'];
    }
}
/** Product copy (Chinese, matching the DSH web UI language). */
declare const COPY: {
    zh: {
        'interpret.banner': string;
        'interpret.hint': string;
    };
    en: {
        'interpret.banner': string;
        'interpret.hint': string;
    };
};
/** Whether a model id is presumed capable of native image input. */
declare function modelSupportsImage(modelId: string): boolean;
/** Minimal structural contracts; the runtime injects the real objects. */
interface VisionDockProps {
    sessionId?: string;
    /** Composer input state, provided to every session-scope entry. */
    useInput?: (selector: (state: unknown) => unknown) => unknown;
    /** Injectable: the shared API client (current model resolution). */
    api?: {
        sessions: {
            models(request: {
                sessionId: string;
            }): Promise<{
                result?: {
                    current?: {
                        model?: string;
                    };
                };
            }>;
        };
    };
    /** Injectable: bound translator for this namespace. */
    t?: (key: string, params?: Record<string, string>) => string;
}
/**
 * Client plugin body: registers the composer dock entry.
 * @param ctx - client cordis context.
 */
export declare const inject: string[];
export declare function apply(ctx: Context): void;
export { modelSupportsImage };
export type { VisionDockProps };
