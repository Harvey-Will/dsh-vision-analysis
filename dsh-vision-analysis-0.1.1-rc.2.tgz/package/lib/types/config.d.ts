/**
 * Plugin configuration: the Schemastery `Config` schema that the Harness
 * settings UI renders, plus pure resolution helpers (endpoint composition,
 * per-mode tuning, API key resolution).
 * @module dsh-universal-vision-analysis/config
 */
import Schema from '@deepseek-ai/schemastery';
import type { ModeTuning, VisionMode } from './modes.js';
/** The vision API wire format spoken by the configured endpoint. */
export type ApiFormat = 'openai' | 'anthropic';
/** Plugin configuration, supplied through cordis.yml and the settings UI. */
export interface Config {
    /** Wire format of the vision endpoint (`openai` chat/completions or `anthropic` messages). */
    apiFormat: ApiFormat;
    /** Base URL of the vision endpoint; a full `/chat/completions` or `/v1/messages` suffix is accepted and kept. */
    baseURL: string;
    /** API key for the vision endpoint. Leave empty for local models (Ollama, LM Studio, vLLM) or to fall back to the `UNIVERSAL_VISION_API_KEY` environment variable. */
    apiKey: string;
    /** Vision model identifier sent to the endpoint. */
    model: string;
    /** Mode used when the caller omits `mode`. */
    defaultMode: VisionMode;
    /** Maximum number of images per call (1-4). */
    maxImages: number;
    /** Per-image byte cap for local files (and a hint for streamed URL bodies). */
    maxBytes: number;
    /** Request timeout in milliseconds. */
    timeoutMs: number;
    /** Default maximum output tokens, used when a mode has no override. */
    maxTokens: number;
    /** Default temperature, used when a mode has no override. */
    temperature: number;
    /** Per-mode output tuning overrides. */
    modes: Partial<Record<VisionMode, ModeTuning>>;
}
/** Environment variable that supplies the API key when `config.apiKey` is empty. */
export declare const API_KEY_ENV = "UNIVERSAL_VISION_API_KEY";
/** Schema of the plugin configuration, validated at load and rendered by the settings UI. */
export declare const Config: Schema<Config>;
/** Error thrown when configuration cannot be used for a call. */
export declare class ConfigError extends Error {
    constructor(message: string);
}
/**
 * Compose the full request endpoint from the configured base URL, keeping a
 * complete `/chat/completions` (OpenAI) or `/v1/messages` (Anthropic) suffix
 * and appending the canonical path otherwise.
 * @param config - resolved configuration.
 * @returns the absolute endpoint URL.
 */
export declare function resolveEndpoint(config: Config): string;
/**
 * Validate that the configuration names an endpoint and a model, returning
 * the normalized endpoint. Fail-loud at load time for a non-empty entry; the
 * tool re-checks per call so an unconfigured mount still reports clearly.
 * @param config - the configuration to resolve.
 * @returns the resolved endpoint URL.
 */
export declare function resolveConfig(config: Config): string;
/**
 * Resolve the API key for one call: inline config value first, then the
 * `UNIVERSAL_VISION_API_KEY` environment variable. Local endpoints may run
 * with no key at all.
 * @param config - the configuration in effect for the call.
 * @returns the trimmed key, or `undefined` when neither source supplies one.
 */
export declare function resolveApiKey(config: Config): string | undefined;
