/**
 * Model-facing `analyze_image` tool for the DeepSeek Harness.
 *
 * One call analyzes one or more images — a local absolute path or an http(s)
 * URL each — through an OpenAI- or Anthropic-compatible vision endpoint and
 * returns only the vision model's text answer, so the image bytes never enter
 * the conversation. Eight analysis modes provide default instructions and
 * output tuning; a caller-supplied `prompt` overrides the mode template. The
 * plugin configuration is editable live from Settings -> 插件配置.
 * @module dsh-vision-analysis
 */
import type { Context } from '@deepseek-ai/cordis';
import { Config } from './config.js';
import type { ApiFormat } from './config.js';
import type { VisionMode } from './modes.js';
/** The plugin's Cordis identity. */
export declare const name = "vision-analysis";
/** Hard dependency on the tool registry; `apply` runs only once it is ready. */
export declare const inject: string[];
/** The settings namespace under which the plugin's configuration is edited. */
export declare const SETTINGS_NAMESPACE = "vision-analysis";
/** The registered tool's canonical call arguments. */
export interface AnalyzeImageArgs {
    /** Local absolute path or http(s) URL of the image to analyze. */
    image?: string;
    /** Up to `maxImages` image sources for a multi-image call; overrides `image`. */
    images?: string[];
    /** One of the eight analysis modes; defaults to the configured `defaultMode`. */
    mode?: VisionMode;
    /** Custom instruction replacing the mode's default template. */
    prompt?: string;
}
/** The canonical output value of one `analyze_image` call. */
export interface AnalyzeImageOutput {
    /** The vision model's text answer (or the debug diagnostics report). */
    text: string;
    /** The mode that produced the answer. */
    mode: string;
    /** The vision model identifier that produced the answer. */
    model: string;
    /** Number of images in the call. */
    imageCount: number;
    /** HTTP status of the vision request, when one was made. */
    httpStatus?: number;
    /** Request latency in milliseconds, when a request was made. */
    latencyMs?: number;
    /** Whether the endpoint signalled token-budget truncation. */
    truncated?: boolean;
}
/**
 * The plugin: registers the settings section and the `analyze_image` tool.
 * @param ctx - registrant context carrying the tool registry.
 * @param config - the composition entry configuration (defaults filled by the loader).
 */
export declare function apply(ctx: Context, config?: Config): void;
export { Config };
export type { ApiFormat };
export { API_KEY_ENV, ConfigError, resolveEndpoint, } from './config.js';
export { composePrompt, MODE_LABELS, MODE_PROMPTS, MODE_TUNING_DEFAULTS, resolveTuning, VISION_MODES, } from './modes.js';
export type { ModeTuning } from './modes.js';
export { IMAGE_EXTENSIONS, ImageSourceError, isDataUrl, loadImage, mimeFromName, parseDataUrl, sniffMime, } from './media.js';
export type { ImageMimeType, LoadedImage } from './media.js';
export { buildVisionBody, callVision, extractVisionText, VisionApiError, } from './vision-client.js';
export type { CallTuning, FetchLike, VisionResult } from './vision-client.js';
