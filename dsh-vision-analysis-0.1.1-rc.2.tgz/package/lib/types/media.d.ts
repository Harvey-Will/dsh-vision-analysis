/**
 * Image source handling: MIME detection by extension and magic bytes, bounded
 * reads for local files and http(s) URLs, and the image-reference model used
 * by the vision client (local files are base64-embedded, URLs are passed
 * through verbatim).
 * @module dsh-universal-vision-analysis/media
 */
/** MIME types this plugin recognizes. */
export type ImageMimeType = 'image/png' | 'image/jpeg' | 'image/gif' | 'image/webp' | 'image/bmp';
/** Image file extensions this plugin recognizes (lowercase, no dot). */
export declare const IMAGE_EXTENSIONS: readonly string[];
/** Bytes-per-megabyte constant for readable size messages. */
export declare const MEGABYTE: number;
/**
 * Map a file extension to a MIME type.
 * @param path - a local path or URL whose last segment carries the extension.
 * @returns the recognized MIME type, or `undefined` for an unknown extension.
 */
export declare function mimeFromName(path: string): ImageMimeType | undefined;
/**
 * Sniff the MIME type from leading magic bytes. JPEG, PNG, GIF, WebP and BMP
 * each carry a recognizable signature; anything else returns `undefined`.
 * @param bytes - the file's leading bytes.
 * @returns the sniffed MIME type, or `undefined` when the signature is unknown.
 */
export declare function sniffMime(bytes: Uint8Array): ImageMimeType | undefined;
/** Whether a source string is an http(s) URL. */
export declare function isHttpUrl(source: string): boolean;
/**
 * Read the body of an http(s) response with a byte cap, honoring the
 * `content-length` header and then streaming with a hard cap so an oversized
 * or hostile body cannot be buffered whole.
 * @param response - a fetched response whose body has not been consumed.
 * @param maxBytes - per-image byte cap.
 * @returns the buffered bytes and the response's content-type header, if any.
 */
export declare function readBoundedResponse(response: Response, maxBytes: number): Promise<{
    bytes: Uint8Array;
    contentType: string | null;
}>;
/** One image ready to send to a vision endpoint. */
export interface LoadedImage {
    /** The caller's original source string (path or URL). */
    source: string;
    /** The image MIME type, resolved from extension, magic bytes, or content-type. */
    mimeType: ImageMimeType;
    /** Base64 data for local files; `undefined` when the image is passed as a URL. */
    base64?: string;
    /** Size of the underlying bytes for local files; `undefined` for URLs. */
    bytes?: number;
}
/** Error thrown when a local path does not exist or is not a regular file. */
export declare class ImageSourceError extends Error {
    constructor(message: string);
}
/** Whether a source string is a base64 data URL. */
export declare function isDataUrl(source: string): boolean;
/**
 * Parse a base64 image data URL (`data:image/png;base64,<data>`) into bytes
 * and its declared MIME type, enforcing the byte cap.
 * @param source - the data URL.
 * @param maxBytes - per-image byte cap.
 * @returns the decoded bytes and normalized MIME type.
 */
export declare function parseDataUrl(source: string, maxBytes: number): {
    bytes: Uint8Array;
    mimeType: ImageMimeType;
};
/**
 * Resolve one image source to a MIME type (and bytes for local files and data
 * URLs). URL sources are passed through by reference — the vision endpoint
 * fetches them — after basic URL and extension checks. Local paths are read
 * with a byte cap and embedded as base64; data URLs are decoded in place.
 * @param source - an absolute local path, an http(s) URL, or a `data:image/...;base64,` URL.
 * @param maxBytes - per-image byte cap for local files and data URLs.
 * @param signal - cancellation forwarded to the URL fetch.
 * @returns the loaded image reference.
 */
export declare function loadImage(source: string, maxBytes: number, signal: AbortSignal): Promise<LoadedImage>;
