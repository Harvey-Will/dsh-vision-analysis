/**
 * The eight analysis modes of the `analyze_image` tool: their identifiers,
 * per-mode output tuning defaults, and the instruction templates the vision
 * model receives when the caller does not supply a custom `prompt`.
 * @module dsh-universal-vision-analysis/modes
 */
/** The eight analysis modes offered by the tool. */
export type VisionMode = 'describe' | 'ocr' | 'ui-review' | 'chart-data' | 'object-detect' | 'compare' | 'code-gen' | 'debug';
/** All mode identifiers in catalog order (also the schema `enum` order). */
export declare const VISION_MODES: readonly VisionMode[];
/** Output tuning a caller or deployment may override per mode. */
export interface ModeTuning {
    /** Maximum output tokens the vision model may produce for this mode. */
    maxTokens?: number;
    /** Sampling temperature for this mode. */
    temperature?: number;
}
/**
 * Default per-mode output tuning. `ocr` and `chart-data` use temperature 0 for
 * maximum fidelity; `code-gen` allows the largest token budget because a UI
 * reconstruction can be long.
 */
export declare const MODE_TUNING_DEFAULTS: Readonly<Record<VisionMode, ModeTuning>>;
/** One-line human label per mode, used in the tool schema and call cards. */
export declare const MODE_LABELS: Readonly<Record<VisionMode, string>>;
/**
 * Default instruction templates. Each template asks for the same language as
 * the surrounding conversation rather than hard-coding one. The templates
 * reference the image(s) already attached by the caller; `{count}` is the
 * number of images in the call and is substituted by the caller.
 */
export declare const MODE_PROMPTS: Readonly<Record<VisionMode, string>>;
/**
 * Resolve the effective output tuning for one mode: a per-mode override from
 * configuration when present, otherwise the built-in per-mode default.
 * @param mode - the selected analysis mode.
 * @param global - deployment-wide defaults (fallbacks when a mode lacks an override).
 * @param overrides - per-mode configuration overrides, keyed by mode.
 * @returns the effective maxTokens and temperature.
 */
export declare function resolveTuning(mode: VisionMode, global: {
    maxTokens: number;
    temperature: number;
}, overrides: Readonly<Partial<Record<VisionMode, ModeTuning>>>): {
    maxTokens: number;
    temperature: number;
};
/**
 * Compose the final instruction for a call: the caller's custom `prompt` when
 * given, otherwise the mode template with `{count}` substituted.
 * @param mode - the selected analysis mode.
 * @param imageCount - number of images in the call.
 * @param customPrompt - caller-supplied instruction, when present.
 * @returns the text prompt sent to the vision model.
 */
export declare function composePrompt(mode: VisionMode, imageCount: number, customPrompt?: string): string;
