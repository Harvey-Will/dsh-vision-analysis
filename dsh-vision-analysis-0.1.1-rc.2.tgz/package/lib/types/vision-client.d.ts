/**
 * The vision HTTP client: request construction for the OpenAI
 * `chat/completions` and Anthropic `messages` wire formats, the bounded
 * fetch with cancellation and timeout, and response validation/extraction.
 * @module dsh-universal-vision-analysis/vision-client
 */
import type { Config } from './config.js';
import type { LoadedImage } from './media.js';
import type { VisionMode } from './modes.js';
/** Effective output tuning for one call. */
export interface CallTuning {
    maxTokens: number;
    temperature: number;
}
/** The outcome of one successful vision request. */
export interface VisionResult {
    /** The extracted text answer. */
    text: string;
    /** HTTP status of the response. */
    httpStatus: number;
    /** Wall-clock latency of the request in milliseconds. */
    latencyMs: number;
    /** Whether the endpoint signalled that the output hit the token budget. */
    truncated: boolean;
    /** The endpoint's own finish/stop reason, when present. */
    finishReason?: string;
}
/** Error thrown for a non-2xx response or an endpoint-declared error. */
export declare class VisionApiError extends Error {
    readonly httpStatus?: number;
    constructor(message: string, httpStatus?: number);
}
/**
 * Build the JSON request body for one format.
 * @param config - resolved configuration.
 * @param prompt - the composed instruction text.
 * @param images - the loaded images.
 * @param tuning - effective output tuning.
 * @returns the request body object (JSON-serializable).
 */
export declare function buildVisionBody(config: Config, prompt: string, images: readonly LoadedImage[], tuning: CallTuning): unknown;
/**
 * Extract the answer text from a parsed response, validating the endpoint's
 * error envelope and detecting token-budget truncation.
 * @param config - resolved configuration (selects the format).
 * @param json - the parsed response body.
 * @returns the extracted text, truncation flag, and finish/stop reason.
 */
export declare function extractVisionText(config: Config, json: unknown): {
    text: string;
    truncated: boolean;
    finishReason?: string;
};
/** The shape of the global fetch function, injectable for tests. */
export type FetchLike = typeof fetch;
/**
 * Perform one vision request: build the body, fetch with caller cancellation
 * and a timeout, validate the HTTP status, and extract the answer.
 * @param config - resolved configuration.
 * @param endpoint - the composed endpoint URL.
 * @param prompt - the composed instruction text.
 * @param images - the loaded images.
 * @param tuning - effective output tuning.
 * @param signal - caller cancellation, forwarded to the request.
 * @param fetchImpl - fetch implementation (defaults to the global fetch).
 * @returns the validated result.
 */
export declare function callVision(config: Config, endpoint: string, prompt: string, images: readonly LoadedImage[], tuning: CallTuning, signal: AbortSignal, fetchImpl?: FetchLike): Promise<VisionResult>;
/** The mode identifiers that participate in a `compare`-style multi-image call. */
export declare const MULTI_IMAGE_MODES: readonly VisionMode[];
